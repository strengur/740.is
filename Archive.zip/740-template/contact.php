<h1>Sendu mér línu!</h1>
<h4><a href="mailto:info@740.is" class="mailto">info[hjá]740.is</a> og ég hef samband</h4>